import pytube, os, getpass
from pytube import YouTube, Playlist, version
from pytube import streams
from pytube.extract import video_id
from pytube.request import stream
from pytube.streams import Stream

PlayName = input("what do you want to call the playlist:")


def GetPlaylistLink():
  PlaylistUrl = getpass.getpass(prompt="enter Playlist Url")
  playlist = Playlist(PlaylistUrl)
  Urls = playlist.video_urls
  print("\n", "\n", "Playlist:", playlist.title)
  #u = open("urls.txt", "w")
  #u.write(str(Urls))
  os.mkdir(PlayName)

  def DownloadTheSongs():
    list = Urls
    for url in list:
      yt = YouTube(url, use_oauth=False, allow_oauth_cache=True)
      stream = yt.streams.get_highest_resolution()
      if stream is not None:
        
        #stream.download(filename=yt.title + ".mp3", output_path=(PlayName))
        try:
          stream.download(filename=yt.title + ".mp3", output_path=(PlayName))
        except Exception as e:
          
          print("\n"f"Error downloading {yt.title}:""\n")
        pass


        print("Downloaded", yt.title)
      else:
        print("No suitable stream found for", yt.title)

  Usrinput = input("Download The songs? Songs?(y/n)")
  if Usrinput == "y":
    print("aight bet one sec")
    DownloadTheSongs()
  else:
    print("aight")


GetPlaylistLink()
print("Finished")
